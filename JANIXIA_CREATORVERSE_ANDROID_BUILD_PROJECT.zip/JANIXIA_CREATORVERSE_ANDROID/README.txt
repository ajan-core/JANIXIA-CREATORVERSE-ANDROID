JANIXIA CREATORVERSE — ANDROID APK BUILD PROJECT

This package contains the Android WebView app wrapper and a GitHub Actions workflow that builds a debug APK. It is source/build material, NOT an already-built APK.

App ID: com.janixia.creatorverse
App name: JANIXIA CREATORVERSE
Minimum Android: Android 6.0 (API 23)
Web app: app/src/main/assets/index.html
Backend: Supabase project fwysrkosckoleyvphctv (publishable browser key only; no service-role key included)

BUILD ON GITHUB USING A PHONE
1. Create a NEW empty repository on GitHub named JANIXIA-CREATORVERSE-ANDROID.
2. Upload the contents of this ZIP to the repository root (make sure .github/workflows/build-apk.yml is included; GitHub mobile upload may hide dot-folders, so use GitHub's web desktop mode if necessary).
3. Open the repository's Actions tab.
4. Select “Build JANIXIA CREATORVERSE APK” and tap “Run workflow”, or wait for the push-triggered build.
5. Open the completed workflow run. Under Artifacts, download JANIXIA-CREATORVERSE-debug-APK.zip.
6. Extract it and install app-debug.apk. Android may ask permission to install unknown apps for the browser/file manager you used.

IMPORTANT
- This debug APK is unsigned for Play Store release but can normally be installed directly on Android.
- Test account signup, login, uploads, downloads, and back navigation on the phone. Email confirmation / Supabase redirect configuration may need adjustment for native WebView use.
- The app needs internet for Supabase and its JavaScript CDN.
- Never put a Supabase secret/service_role key in this app.
- This package has not yet been built in a real Android SDK environment or end-to-end tested on a physical phone. Do not treat it as a verified APK until the GitHub Actions build succeeds.
